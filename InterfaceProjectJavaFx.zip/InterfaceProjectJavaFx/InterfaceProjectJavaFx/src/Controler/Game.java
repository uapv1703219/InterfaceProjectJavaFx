package Controler;

import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Game extends Application{

	@Override
	public void start(Stage stage) throws Exception {
		try
    	{
    	Parent root = FXMLLoader.load(getClass().getResource("../View/playWindow.fxml"));
        stage.setTitle("Morpion : Game");
        stage.setScene(new Scene(root));
        stage.show();
        }
    	catch(IOException e)
    	{
    		e.printStackTrace();
    	}
	}
	
	public void homeReturn(ActionEvent event) throws IOException {
		ImageView imageView = (ImageView) ( ((Node) event.getSource()).getScene().lookup("#home"));
		try 
		{
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("../View/mainMenu.fxml"));
	        Stage stage = (Stage) imageView.getScene().getWindow();
	        Scene scene = new Scene(loader.load());
	        stage.setScene(scene);
	        stage.setTitle("Morpion : Main Menu");
	    }
		catch (IOException io)
		{
	        io.printStackTrace();
	    }
	}

}
